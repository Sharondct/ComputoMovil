//
//  TriviaViewController.swift
//  AppSegundoParcial
//
//  Created by macbook on 4/29/19.
//  Copyright © 2019 Sharon. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {
    
    
    @IBOutlet weak var switch1: UISwitch!
    
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var switch3: UISwitch!
    
    @IBOutlet weak var validar: UIButton!
    
    var correctAnswers = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    
    @IBAction func validarRespuestas(_ sender: Any) {
        correctAnswers = 0
        
        if switch1.isOn {
            correctAnswers += 1
        }
        
        if switch2.isOn == false {
            correctAnswers += 1
        }
        
        if switch3.isOn == false{
            correctAnswers += 1
        }
        
        if correctAnswers == 3 {
            performSegue(withIdentifier: "Correcto", sender: self)
        }else{
            performSegue(withIdentifier: "Incorrecto", sender: self)
        }
    }
}

