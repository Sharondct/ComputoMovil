//: [Previous](@previous)

import Foundation

// var2:Int? = nil
func printFullName(firstName: String, middleName: String?, lastName: String)->String?{
    if let middleName = middleName {
        return(firstName+middleName+lastName)
    }
    else {
     return nil
    }
}
//printFullName(firstName: "Sharon", middleName: nil, lastName: "Cuallo")

let fullName = printFullName(firstName: "Sharon", middleName: nil, lastName: "Cuallo")

if let fullName = fullName {
    print(fullName)
}

//: [Next](@next)
