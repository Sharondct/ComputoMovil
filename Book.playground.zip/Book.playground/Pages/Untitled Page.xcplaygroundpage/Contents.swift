import UIKit

struct Book {
    var name: String
    var publicationYear: Int? // "?" Opcional. Puede no tener un valor "publicationYear".
    init?(name:String,publicationYear:Int?){
        if let publicationYear = publicationYear {
            self.name = name
            self.publicationYear = publicationYear
        }
        else {
            return nil
        }
    }
}

let firstHarryPotter = Book(name:"Harry Potter and the Sorcerer's Stone", publicationYear: 1997)
let secondHarryPotter=Book(name:"Harry Potter and the Chamber of Secrets", publicationYear: 1998)
let thirdHarryPotter=Book(name:"Harry Potter and the Prisoner of Azkaban", publicationYear: 2000)
let unannouncedBook = Book(name: "Rebels and Lions", publicationYear: nil)

let books = [firstHarryPotter, secondHarryPotter, thirdHarryPotter, unannouncedBook]
for item in books{
    if let constant = item?.publicationYear { // Encadenamiento de un Wrap (Opcional)
        print(constant)
    }
  }
    // print(item.publicationYear!) "!" Para quitar Warning. Estoy segura del valor asignado a "publicationYear" despues de haber puesto "?" a INT.

// LIBRO "LEARN SWIFT TODAY" HACKING WITH SWIFT. 
