import UIKit

var str = "Hello, playground"


let videoLength = 12453
let videoLengthTooShortReaction = "¡Parpadeo y me lo pierdo!"
let videoReasonableLengthReaction = "Es muy bueno."
let videoMessage = "El video dura \(videoLength)(duración del video) segundos. \(videoLengthTooShortReaction)"

if videoLength < 5 {
    print("El video dura \(videoLength)(duración del video) segundos. \(videoLengthTooShortReaction)")
    
}
if videoLength >= 5 {
    print("El video dura \(videoLength)(duración del video) segundos. \(videoReasonableLengthReaction)")
    
}

if videoLength > 5 {
    print("El video dura \(videoLength)(duración del video) segundos. \(videoLengthTooShortReaction)")
}

else if videoLength == 5 {
print("El video dura \(videoLength) (duración del video) segundos. \(videoReasonableLengthReaction)")
}
else {
    print(videoReasonableLengthReaction)
}



