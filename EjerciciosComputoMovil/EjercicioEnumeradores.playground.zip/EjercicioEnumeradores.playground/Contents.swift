import UIKit

var str = "Hello, playground"

func orden(platillo: String) -> String {
    if platillo == "sopa" {
        return "🍲"
    }
    else {
        return "No está en el menú"
    }
}

orden(platillo: "Sopa")

enum Platillo {
    case sopa, pescado, res, pollo
}

func orden(platillo: Platillo) {
    switch platillo {
    case .sopa:
        print("🍲")
    default:
        print ("No está en el menú")
    }
}

orden(platillo: .sopa)
